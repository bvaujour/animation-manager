import datetime

from django.test import TestCase
from django.utils import timezone

from animateurs.models import Affectation, Animateur, Centre, Disponibilite
from animateurs.services.affectations import creer_affectation, modifier_affectation


class AffectationServiceTests(TestCase):
    def setUp(self):
        self.animateur = Animateur.objects.create(prenom="Julie", nom="Test")
        self.centre_a = Centre.objects.create(nom="Centre A", code="A", couleur="#123456")
        self.centre_b = Centre.objects.create(nom="Centre B", code="B", couleur="#654321")
        self.jour = timezone.make_aware(datetime.datetime(2026, 7, 6))

    def test_refuse_un_doublon_le_meme_jour(self):
        creer_affectation(
            animateur=self.animateur,
            centre=self.centre_a,
            debut=self.jour,
            fin=self.jour + datetime.timedelta(days=1),
        )
        with self.assertRaisesMessage(ValueError, "déjà une affectation"):
            creer_affectation(
                animateur=self.animateur,
                centre=self.centre_b,
                debut=self.jour,
                fin=self.jour + datetime.timedelta(days=1),
            )

    def test_refuse_un_jour_hors_disponibilite(self):
        Disponibilite.objects.create(
            animateur=self.animateur,
            debut=datetime.date(2026, 7, 7),
            fin=datetime.date(2026, 7, 7),
        )
        with self.assertRaisesMessage(ValueError, "n'est pas disponible"):
            creer_affectation(
                animateur=self.animateur,
                centre=self.centre_a,
                debut=self.jour,
                fin=self.jour + datetime.timedelta(days=1),
            )

    def test_deplacement_change_le_centre(self):
        affectation = creer_affectation(
            animateur=self.animateur,
            centre=self.centre_a,
            debut=self.jour,
            fin=self.jour + datetime.timedelta(days=1),
        )
        modifier_affectation(affectation, centre=self.centre_b)
        affectation.refresh_from_db()
        self.assertEqual(affectation.centre, self.centre_b)
