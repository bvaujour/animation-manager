import datetime

from django.test import TestCase

from animateurs.models import Affectation, Animateur, Centre, Disponibilite, Qualification
from animateurs.services.planning_solver import generer_planning_auto


class PlanningSolverTests(TestCase):
    def setUp(self):
        self.centre = Centre.objects.create(
            nom="Centre test", code="CT", couleur="#123456", effectif_cible=1
        )
        self.bafa = Qualification.objects.create(nom="BAFA")
        self.qualifie = Animateur.objects.create(prenom="Qualifié", nom="Test")
        self.qualifie.qualifications.add(self.bafa)
        self.non_qualifie = Animateur.objects.create(prenom="Sans", nom="Qualification")

    def test_respecte_qualification_demandee(self):
        payload = {
            "debut": "2026-07-06",
            "centres": {
                str(self.centre.id): {
                    "effectif": 1,
                    "qualifs": {str(self.bafa.id): 1},
                }
            },
        }
        data, status = generer_planning_auto(payload)
        self.assertEqual(status, 200)
        self.assertTrue(data["ok"])
        self.assertEqual(data["created"], 5)
        self.assertFalse(
            Affectation.objects.exclude(animateur=self.qualifie).exists()
        )
        self.assertTrue(
            all(affectation.debut.date().weekday() < 5 for affectation in Affectation.objects.all())
        )

    def test_respecte_les_disponibilites(self):
        # Le qualifié n'est disponible que le lundi. Le reste doit rester vide
        # puisqu'une qualification BAFA est demandée chaque jour.
        Disponibilite.objects.create(
            animateur=self.qualifie,
            debut=datetime.date(2026, 7, 6),
            fin=datetime.date(2026, 7, 6),
        )
        payload = {
            "debut": "2026-07-06",
            "centres": {
                str(self.centre.id): {
                    "effectif": 1,
                    "qualifs": {str(self.bafa.id): 1},
                }
            },
        }
        data, status = generer_planning_auto(payload)
        self.assertEqual(status, 200)
        self.assertEqual(data["created"], 1)
        affectation = Affectation.objects.get()
        self.assertEqual(affectation.debut.date(), datetime.date(2026, 7, 6))
