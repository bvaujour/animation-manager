from pathlib import Path

from django.conf import settings
from animateurs.tests.base import ConnexionTestCase


class InterfaceHarmonisationTests(ConnexionTestCase):
    def test_accueil_et_planning_chargent_le_style_calendrier_partage(self):
        accueil = self.client.get("/")
        planning = self.client.get("/planning/")

        self.assertEqual(accueil.status_code, 200)
        self.assertEqual(planning.status_code, 200)
        self.assertContains(accueil, "css/calendars.css")
        self.assertContains(planning, "css/calendars.css")
        self.assertContains(accueil, 'class="home-calendars calendar-sites"')
        self.assertContains(planning, 'class="planning-view-week calendar-sites"')

    def test_planning_force_une_colonne_de_calendriers_et_respecte_hidden(self):
        css = (Path(settings.BASE_DIR) / "static/css/calendars.css").read_text()

        self.assertIn("flex-direction: column !important", css)
        self.assertIn(".calendar-site-card[hidden]", css)
        self.assertIn("display: none !important", css)

    def test_les_interfaces_de_periodes_sont_rangees_par_annee(self):
        fichiers = [
            "static/js/gestion.js",
            "static/js/animateurs.js",
            "static/js/recapitulatif.js",
        ]
        for fichier in fichiers:
            contenu = (Path(settings.BASE_DIR) / fichier).read_text()
            self.assertIn("grouperPeriodesParAnnee", contenu, fichier)
            self.assertIn("period-year-accordion", contenu, fichier)

    def test_helpers_communs_des_annees_scolaires_sont_presents(self):
        contenu = (Path(settings.BASE_DIR) / "static/js/ui.js").read_text()

        self.assertIn("function anneeScolaireCourante", contenu)
        self.assertIn("function grouperPeriodesParAnnee", contenu)
        self.assertIn("function anneePeriodesADeplier", contenu)
    def test_la_couche_de_composants_est_chargee_apres_les_styles_de_page(self):
        base = (Path(settings.BASE_DIR) / "templates/base.html").read_text()

        self.assertIn("css/components.css", base)
        self.assertGreater(base.index("css/components.css"), base.index("block extra_head"))

    def test_les_pages_principales_utilisent_le_shell_et_les_cartes_communes(self):
        attentes = {
            "templates/accueil.html": ["page-shell", "ui-card"],
            "templates/administration.html": ["page-shell", "ui-card"],
            "templates/documents_partages.html": ["page-shell", "page-header", "ui-grid"],
            "templates/employes.html": ["page-shell", "employees-workspace", "employees-sidebar", "employee-editor", "ui-card"],
            "templates/gestion.html": ["page-shell", "ui-card"],
            "templates/mes_disponibilites.html": ["page-shell", "page-header", "ui-card"],
            "templates/recapitulatif.html": ["page-shell", "page-header", "ui-card"],
        }
        for fichier, classes in attentes.items():
            contenu = (Path(settings.BASE_DIR) / fichier).read_text()
            for classe in classes:
                self.assertIn(classe, contenu, fichier)

    def test_l_ancienne_page_salarie_autonome_est_supprimee(self):
        template = Path(settings.BASE_DIR) / "templates/employe_detail.html"
        self.assertFalse(template.exists())

        contenu = (Path(settings.BASE_DIR) / "templates/employes.html").read_text()
        self.assertIn("employees-sidebar", contenu)
        self.assertIn("employee-editor", contenu)

    def test_le_script_email_definit_l_affichage_de_configuration(self):
        contenu = (Path(settings.BASE_DIR) / "static/js/emails.js").read_text()

        self.assertIn("function afficherConfiguration()", contenu)
        self.assertGreaterEqual(contenu.count("afficherConfiguration"), 2)

    def test_les_variables_de_densite_sont_centralisees(self):
        css = (Path(settings.BASE_DIR) / "static/css/components.css").read_text()

        self.assertIn("--page-gutter", css)
        self.assertIn("--card-padding", css)
        self.assertIn("--control-height", css)
        self.assertIn(".page-shell", css)
        self.assertIn(".ui-card", css)

