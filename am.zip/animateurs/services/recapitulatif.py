"""Comptage des jours planifiés par animateur sur une période donnée."""

from __future__ import annotations

import datetime
from collections import defaultdict

from django.utils import timezone

from animateurs.models import Affectation


def _jours_entre(debut: datetime.date, fin_exclusive: datetime.date):
    """Itère de ``debut`` inclus à ``fin_exclusive`` exclu."""

    jour = debut
    while jour < fin_exclusive:
        yield jour
        jour += datetime.timedelta(days=1)


def generer_recapitulatif(debut, fin, jours_selectionnes=None):
    """Retourne le nombre de dates uniques affectées à chaque animateur.

    ``debut`` est inclus et ``fin`` est exclusif. Lorsqu'un animateur possède
    plusieurs affectations le même jour, cette date ne compte qu'une seule fois.
    """

    debut_date = debut.date()
    fin_date = fin.date()
    jours_autorises = set(_jours_entre(debut_date, fin_date))
    if jours_selectionnes is not None:
        jours_autorises &= set(jours_selectionnes)

    affectations = (
        Affectation.objects.select_related("animateur")
        .filter(debut__lt=fin, fin__gt=debut)
        .order_by("animateur__prenom", "animateur__nom", "debut")
    )

    jours_par_animateur = defaultdict(set)
    animateurs = {}

    for affectation in affectations:
        animateur = affectation.animateur
        animateurs[animateur.id] = animateur

        debut_affectation = max(timezone.localtime(affectation.debut).date(), debut_date)
        fin_affectation = min(timezone.localtime(affectation.fin).date(), fin_date)
        for jour in _jours_entre(debut_affectation, fin_affectation):
            if jour in jours_autorises:
                jours_par_animateur[animateur.id].add(jour)

    lignes = [
        {
            "id": animateur.id,
            "prenom": animateur.prenom,
            "nom": animateur.nom,
            "jours_travailles": len(jours_par_animateur[animateur.id]),
        }
        for animateur in animateurs.values()
        if jours_par_animateur[animateur.id]
    ]
    lignes.sort(key=lambda ligne: (-ligne["jours_travailles"], ligne["prenom"].casefold(), ligne["nom"].casefold()))

    return {
        "animateurs": lignes,
        "total_jours": sum(ligne["jours_travailles"] for ligne in lignes),
    }
