document.addEventListener("DOMContentLoaded", () => {
    const $ = (id) => document.getElementById(id);
    const selectRoot = $("periode-select");
    const selectToggle = $("periode-select-toggle");
    const selectLabel = $("periode-select-label");
    const selectMenu = $("periode-select-menu");
    const selectOptions = $("periode-select-options");
    const btnToutSelectionner = $("periodes-tout-selectionner");
    const btnToutDeselectionner = $("periodes-tout-deselectionner");
    const btnAppliquer = $("btn-appliquer-periode");
    const periodeAffichee = $("periode-affichee");
    const salariesRoot = $("recap-salaries");

    let periodes = [];
    const periodeIdsSelectionnees = new Set();
    const anneesPeriodesOuvertes = new Set();

    function formatDateFr(dateStr) {
        if (!dateStr) return "";
        return parseLocalDate(dateStr).toLocaleDateString("fr-FR");
    }

    function mettreAJourLibelleSelection() {
        const selection = periodes.filter((periode) => periodeIdsSelectionnees.has(periode.id));
        if (!selection.length) {
            selectLabel.textContent = "Choisir les périodes";
            periodeAffichee.textContent = "Aucune période sélectionnée";
            return;
        }
        selectLabel.textContent = selection.length === 1
            ? libellePeriodeAvecAnnee(selection[0])
            : `${selection.length} périodes sélectionnées`;
        periodeAffichee.textContent = selection.length === 1
            ? `${formatDateFr(selection[0].debut)} au ${formatDateFr(selection[0].fin)}`
            : selection.map(libellePeriodeAvecAnnee).join(" · ");
    }

    // Harmonisation avec le classement partagé grouperPeriodesParAnnee : année → vacances → semaines.
    function rendreOptionsPeriodes() {
        const periodeActuelle = periodes.find((periode) => Boolean(periode.est_actuelle));
        const annees = new Map();
        periodes.forEach((periode) => {
            const annee = periode.annee_scolaire || "Année non définie";
            const vacances = periode.vacances || periode.nom || "Autres périodes";
            if (!annees.has(annee)) annees.set(annee, new Map());
            if (!annees.get(annee).has(vacances)) annees.get(annee).set(vacances, []);
            annees.get(annee).get(vacances).push(periode);
        });
        selectOptions.innerHTML = [...annees.entries()]
            .sort(([a], [b]) => String(b).localeCompare(String(a), "fr"))
            .map(([annee, vacancesMap], indexAnnee) => {
                const anneeActuelle = periodeActuelle && String(periodeActuelle.annee_scolaire || "Année non définie") === String(annee);
                const vacancesHtml = [...vacancesMap.entries()]
                    .sort(([, a], [, b]) => String(a[0]?.debut || "").localeCompare(String(b[0]?.debut || "")) )
                    .map(([vacances, semaines], indexVacances) => {
                        const vacancesActuelles = semaines.some((periode) => Boolean(periode.est_actuelle));
                        return `<details class="email-week-vacation" ${periodeActuelle ? (vacancesActuelles ? "open" : "") : (indexAnnee === 0 && indexVacances === 0 ? "open" : "")}>
                            <summary>${escapeHtml(vacances)}</summary>
                            ${semaines.sort((a,b) => a.debut.localeCompare(b.debut)).map((periode) => `<label class="email-week-option">
                                <input type="checkbox" value="${periode.id}" ${periodeIdsSelectionnees.has(periode.id) ? "checked" : ""}>
                                <span><strong>${escapeHtml(periode.semaine || periode.nom)}</strong><small>${escapeHtml(formatDateFr(periode.debut))} au ${escapeHtml(formatDateFr(periode.fin))}</small></span>
                            </label>`).join("")}
                        </details>`;
                    }).join("");
                return `<details class="email-week-year period-year-accordion" ${periodeActuelle ? (anneeActuelle ? "open" : "") : (indexAnnee === 0 ? "open" : "")}>
                    <summary>${escapeHtml(annee)}</summary>${vacancesHtml}
                </details>`;
            }).join("");

        selectOptions.querySelectorAll('input[type="checkbox"]').forEach((checkbox) => checkbox.addEventListener("change", () => {
            const id = Number(checkbox.value);
            if (checkbox.checked) periodeIdsSelectionnees.add(id);
            else periodeIdsSelectionnees.delete(id);
            mettreAJourLibelleSelection();
        }));
    }

    function construireUrlApi() {
        if (!periodeIdsSelectionnees.size) {
            afficherToast("Sélectionne au moins une période.", true);
            return null;
        }
        return `/api/recapitulatif/?periode_ids=${[...periodeIdsSelectionnees].sort((a, b) => a - b).join(",")}`;
    }

    function afficherSalaries(data) {
        if (!data.animateurs.length) {
            salariesRoot.innerHTML = '<div class="empty-state"><strong>Aucun jour planifié</strong><span>Aucun animateur n’est affecté sur cette période.</span></div>';
            return;
        }

        const lignes = data.animateurs.map((animateur) => `
            <tr>
                <td>${escapeHtml(animateur.prenom)} ${escapeHtml(animateur.nom)}</td>
                <td class="jours-cell">${animateur.jours_travailles}</td>
            </tr>`).join("");

        salariesRoot.innerHTML = `
            <table class="recap-table">
                <thead><tr><th>Animateur</th><th>Jours travaillés</th></tr></thead>
                <tbody>${lignes}</tbody>
                <tfoot><tr><th>Total</th><th class="jours-cell">${data.total_jours}</th></tr></tfoot>
            </table>`;
    }

    function chargerRecap() {
        const url = construireUrlApi();
        if (!url) return;
        salariesRoot.innerHTML = '<div class="loading-note">Calcul des jours travaillés…</div>';
        btnAppliquer.disabled = true;
        apiFetch(url)
            .then(afficherSalaries)
            .catch((err) => afficherToast(erreurMessage(err, "Le récapitulatif n’a pas pu être chargé."), true))
            .finally(() => { btnAppliquer.disabled = false; });
    }

    function definirToutesLesPeriodes(selectionnees) {
        periodeIdsSelectionnees.clear();
        if (selectionnees) periodes.forEach((p) => periodeIdsSelectionnees.add(p.id));
        rendreOptionsPeriodes();
        mettreAJourLibelleSelection();
    }

    selectToggle.addEventListener("click", () => {
        const ouvrir = selectMenu.hidden;
        selectMenu.hidden = !ouvrir;
        selectToggle.setAttribute("aria-expanded", String(ouvrir));
    });
    document.addEventListener("click", (event) => {
        if (!selectRoot.contains(event.target)) {
            selectMenu.hidden = true;
            selectToggle.setAttribute("aria-expanded", "false");
        }
    });
    btnToutSelectionner.addEventListener("click", () => definirToutesLesPeriodes(true));
    btnToutDeselectionner.addEventListener("click", () => definirToutesLesPeriodes(false));
    btnAppliquer.addEventListener("click", () => {
        selectMenu.hidden = true;
        selectToggle.setAttribute("aria-expanded", "false");
        chargerRecap();
    });

    apiFetch("/api/periodes-scolaires/").then((data) => {
        periodes = [...data].sort((a, b) => a.debut.localeCompare(b.debut));
        rendreOptionsPeriodes();
        mettreAJourLibelleSelection();
        if (periodes.length) salariesRoot.innerHTML = '<div class="empty-state"><strong>Sélectionne une ou plusieurs semaines</strong><span>Puis clique sur Afficher.</span></div>';
        else {
            selectLabel.textContent = "Aucune période enregistrée";
            btnAppliquer.disabled = true;
        }
    }).catch((err) => afficherToast(erreurMessage(err, "Les périodes n’ont pas pu être chargées."), true));
});
