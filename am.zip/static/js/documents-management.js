document.addEventListener("DOMContentLoaded", () => {
    const app = document.getElementById("documents-management-app");
    if (!app) return;

    const grid = document.getElementById("documents-grid");
    const form = document.getElementById("form-upload");
    const titreInput = document.getElementById("doc-titre");
    const fichierInput = document.getElementById("doc-fichier");
    const errorEl = document.getElementById("doc-error");
    const picker = document.getElementById("doc-semaines-picker");
    const toggle = document.getElementById("doc-semaines-toggle");
    const label = document.getElementById("doc-semaines-label");
    const menu = document.getElementById("doc-semaines-menu");
    const tree = document.getElementById("doc-semaines-tree");
    const clearButton = document.getElementById("doc-semaines-effacer");
    let periodes = [];

    const selectedIds = (root = tree) => Array.from(root.querySelectorAll('input[data-periode-id]:checked')).map(input => Number(input.dataset.periodeId));
    const formatDateFr = iso => { const [a,m,j] = String(iso || "").split("-"); return a && m && j ? `${j}/${m}/${a}` : iso || ""; };
    function updateLabel(root = tree, target = label) {
        const ids = new Set(selectedIds(root).map(String));
        const selection = periodes.filter(p => ids.has(String(p.id)));
        target.textContent = !selection.length ? "Choisir des semaines" : selection.length === 1 ? (selection[0].libelle || selection[0].nom) : `${selection.length} semaines sélectionnées`;
    }
    function groupDetails(title, className) { const d=document.createElement("details"); d.className=className; const s=document.createElement("summary"); s.textContent=title; d.appendChild(s); return d; }
    function renderTree(root = tree, selected = []) {
        const keep = new Set(selected.map(String)); root.innerHTML = "";
        const aujourdHui = new Date();
        const dateLocale = `${aujourdHui.getFullYear()}-${String(aujourdHui.getMonth() + 1).padStart(2, "0")}-${String(aujourdHui.getDate()).padStart(2, "0")}`;
        const estPeriodeActuelle = p => p.est_actuelle === true
            || String(p.est_actuelle).toLowerCase() === "true"
            || (String(p.debut || "") <= dateLocale && dateLocale <= String(p.fin || ""));
        const current = periodes.find(estPeriodeActuelle);
        const years = new Map();
        periodes.forEach(p => { const y=p.annee_scolaire || "Année non définie"; const v=p.vacances || p.nom || "Autres périodes"; if(!years.has(y)) years.set(y,new Map()); if(!years.get(y).has(v)) years.get(y).set(v,[]); years.get(y).get(v).push(p); });
        [...years.entries()].sort(([a],[b])=>String(b).localeCompare(String(a),"fr")).forEach(([year,vacations], yi) => {
            const yd=groupDetails(year,"email-week-year"); yd.open=current ? String(current.annee_scolaire || "Année non définie")===String(year) : yi===0;
            [...vacations.entries()].sort(([,a],[,b])=>String(a[0]?.debut).localeCompare(String(b[0]?.debut))).forEach(([vac,weeks], vi) => {
                const vd=groupDetails(vac,"email-week-vacation"); vd.open=current ? weeks.some(estPeriodeActuelle) : yi===0&&vi===0;
                weeks.sort((a,b)=>String(a.debut).localeCompare(String(b.debut))).forEach(p => {
                    const option=document.createElement("label"); option.className="email-week-option";
                    option.innerHTML=`<input type="checkbox" data-periode-id="${p.id}" ${keep.has(String(p.id)) ? "checked" : ""}><span><strong>${escapeHtml(p.semaine || p.nom)}</strong><small>${escapeHtml(formatDateFr(p.debut))} au ${escapeHtml(formatDateFr(p.fin))}</small></span>`;
                    option.querySelector("input").addEventListener("change",()=>updateLabel(root, root===tree ? label : root.closest("form").querySelector("[data-period-label]")));
                    vd.appendChild(option);
                }); yd.appendChild(vd);
            }); root.appendChild(yd);
        });
        if(!periodes.length) root.innerHTML='<p class="empty-note">Aucune semaine enregistrée.</p>';
    }

    function carteDocument(doc) {
        const extension = DocumentUtils.extension(doc.url); const div=document.createElement("article"); div.className="document-card";
        div.innerHTML=`<div class="document-file-type" aria-hidden="true">${escapeHtml(extension ? extension.toUpperCase() : "FIC")}</div><h3 class="document-title truncate" title="${escapeHtml(doc.titre)}">${escapeHtml(doc.titre)}</h3><p class="document-period-label">${escapeHtml(doc.libelle_periode || "")}</p><div class="document-actions"><a href="${escapeHtml(doc.url)}" target="_blank" rel="noopener" class="btn btn-ghost">Ouvrir</a><button class="btn btn-ghost document-edit" type="button">Modifier</button><button class="btn btn-danger" type="button" aria-label="Supprimer ${escapeHtml(doc.titre)}">&times;</button></div>`;
        div.querySelector(".document-edit").addEventListener("click",()=>{
            if(div.querySelector(".document-inline-editor")) return;
            const editor=document.createElement("form"); editor.className="document-inline-editor";
            editor.innerHTML=`<label>Titre<input type="text" name="titre" value="${escapeHtml(doc.titre)}" required></label><span class="field-label">Semaines concernées</span><div class="email-weeks-picker"><button class="email-weeks-toggle" type="button"><span data-period-label>Choisir des semaines</span><span class="email-weeks-chevron" aria-hidden="true">⌄</span></button><div class="email-weeks-menu" hidden><div class="email-weeks-menu-heading"><span>Année → vacances → semaines</span><button class="btn btn-ghost btn-small clear-periods" type="button">Tout décocher</button></div><div class="email-weeks-tree edit-period-tree"></div></div></div><p class="form-error"></p><div class="editor-actions"><button class="btn btn-primary" type="submit">Enregistrer</button><button class="btn btn-ghost editor-cancel" type="button">Annuler</button></div>`;
            div.appendChild(editor); const ep=editor.querySelector(".email-weeks-picker"), em=editor.querySelector(".email-weeks-menu"), et=editor.querySelector(".edit-period-tree"), el=editor.querySelector("[data-period-label]"); renderTree(et,doc.periode_ids || []); updateLabel(et,el);
            ep.querySelector(".email-weeks-toggle").addEventListener("click",()=>em.hidden=!em.hidden); editor.querySelector(".clear-periods").addEventListener("click",()=>{et.querySelectorAll("input").forEach(i=>i.checked=false);updateLabel(et,el)}); editor.querySelector(".editor-cancel").addEventListener("click",()=>editor.remove());
            editor.addEventListener("submit",async e=>{e.preventDefault(); const ids=selectedIds(et); if(!ids.length){editor.querySelector(".form-error").textContent="Sélectionne au moins une semaine.";return;} try{await apiFetch(`/api/documents/${doc.id}/`,{method:"PATCH",body:JSON.stringify({titre:editor.elements.titre.value.trim(),periode_ids:ids})});afficherToast("Document modifié.");await chargerDocuments();}catch(err){editor.querySelector(".form-error").textContent=erreurMessage(err,"Modification impossible.");}});
        });
        div.querySelector(".btn-danger").addEventListener("click",async()=>{if(!confirm(`Supprimer « ${doc.titre} » ?`))return;try{await apiFetch(`/api/documents/${doc.id}/`,{method:"DELETE"});afficherToast("Document supprimé.");await chargerDocuments();}catch(err){afficherToast(erreurMessage(err,"Suppression impossible."),true);}}); return div;
    }
    function afficherDocuments(documents){grid.innerHTML="";if(!documents.length){grid.innerHTML='<p class="empty-note">Aucun document pour l’instant.</p>';return;}const groups=new Map();documents.forEach(doc=>{const key=(doc.periode_ids||[]).join(",")||"sans-periode";if(!groups.has(key))groups.set(key,{titre:doc.libelle_periode||"Sans période",documents:[]});groups.get(key).documents.push(doc);});groups.forEach(group=>{const section=document.createElement("section");section.className="document-group";section.innerHTML=`<h2>${escapeHtml(group.titre)}</h2><div class="document-group-grid"></div>`;group.documents.forEach(doc=>section.querySelector(".document-group-grid").appendChild(carteDocument(doc)));grid.appendChild(section);});}
    async function chargerDocuments(){try{afficherDocuments(await apiFetch("/api/documents/"));}catch(err){grid.innerHTML=`<p class="form-error">${escapeHtml(erreurMessage(err,"Impossible de charger les documents."))}</p>`;}}
    form.addEventListener("submit",async e=>{e.preventDefault();errorEl.textContent="";const file=fichierInput.files[0],ids=selectedIds();if(!file){errorEl.textContent="Choisis un fichier.";return;}if(!ids.length){errorEl.textContent="Sélectionne au moins une semaine.";return;}const data=new FormData();data.append("titre",titreInput.value.trim());data.append("fichier",file);ids.forEach(id=>data.append("periode_ids",String(id)));try{const r=await fetch("/api/documents/",{method:"POST",headers:{"X-CSRFToken":csrfToken()},body:data});if(!r.ok)throw await r.json();form.reset();tree.querySelectorAll("input").forEach(i=>i.checked=false);updateLabel();afficherToast("Document ajouté.");await chargerDocuments();}catch(err){errorEl.textContent=erreurMessage(err,"Impossible d'ajouter ce document.");}});
    toggle.addEventListener("click",()=>{menu.hidden=!menu.hidden;toggle.setAttribute("aria-expanded",String(!menu.hidden));});document.addEventListener("click",e=>{if(!picker.contains(e.target)){menu.hidden=true;toggle.setAttribute("aria-expanded","false");}});clearButton.addEventListener("click",()=>{tree.querySelectorAll("input").forEach(i=>i.checked=false);updateLabel();});
    Promise.all([apiFetch("/api/periodes-scolaires/"),chargerDocuments()]).then(([data])=>{periodes=[...data].sort((a,b)=>String(a.debut).localeCompare(String(b.debut)));renderTree();updateLabel();}).catch(err=>{errorEl.textContent=erreurMessage(err,"Impossible de charger les périodes.");});
});
