document.addEventListener("DOMContentLoaded", () => {
    const app = document.getElementById("emails-app");
    if (!app) return;

    initTabs(app);

    const form = document.getElementById("form-envoi-email");
    const configuration = document.getElementById("email-configuration");
    const destinatairesRoot = document.getElementById("email-destinataires");
    const contactsRoot = document.getElementById("email-contacts-externes");
    const documentsRoot = document.getElementById("email-documents");
    const recherche = document.getElementById("recherche-destinataire");
    const filtreQualification = document.getElementById("filtre-destinataire-qualification");
    const filtreDisponibilite = document.getElementById("filtre-destinataire-disponibilite");
    const filtreAffectation = document.getElementById("filtre-destinataire-affectation");
    const filtreCentre = document.getElementById("filtre-destinataire-centre");
    const filtreDetails = document.getElementById("email-recipient-filter");
    const filtreCompteur = document.getElementById("email-filter-count");
    const filtreReset = document.getElementById("email-filter-reset");
    const filtreInfo = document.getElementById("destinataires-filtres-info");
    const compteurDest = document.getElementById("destinataires-compteur");
    const compteurDocs = document.getElementById("documents-compteur");
    const erreur = document.getElementById("email-erreur");
    const resultat = document.getElementById("email-resultat");
    const envoyer = document.getElementById("email-envoyer");
    const historiqueRoot = document.getElementById("email-historique");
    const modeleSelect = document.getElementById("email-modele");
    const semainesPicker = document.getElementById("email-semaines-picker");
    const semainesToggle = document.getElementById("email-semaines-toggle");
    const semainesLabel = document.getElementById("email-semaines-label");
    const semainesMenu = document.getElementById("email-semaines-menu");
    const semainesTree = document.getElementById("email-semaines-tree");
    const semainesEffacer = document.getElementById("email-semaines-effacer");
    const variablesRoot = document.getElementById("email-variables");
    const objetInput = document.getElementById("email-objet");
    const messageInput = document.getElementById("email-message");

    const modeleForm = document.getElementById("modele-email-form");
    const modeleIdInput = document.getElementById("modele-email-id");
    const modeleNomInput = document.getElementById("modele-email-nom");
    const modeleObjetInput = document.getElementById("modele-email-objet");
    const modeleMessageInput = document.getElementById("modele-email-message");
    const modeleActifInput = document.getElementById("modele-email-actif");
    const modeleTitre = document.getElementById("modele-email-form-title");
    const modeleErreur = document.getElementById("modele-email-erreur");
    const modeleSupprimer = document.getElementById("modele-email-supprimer");
    const modelesListe = document.getElementById("modeles-email-liste");
    const modelesCompteur = document.getElementById("modeles-compteur");
    const modeleVariablesRoot = document.getElementById("modele-email-variables");

    let champVariableActif = messageInput;
    let champVariableModeleActif = modeleMessageInput;
    let donnees = {
        animateurs: [],
        contacts_externes: [],
        documents: [],
        modeles: [],
        variables: [],
        periodes: [],
        qualifications: [],
        historique: [],
        configuration: {},
    };
    let modelesGestion = [];

    const contactForm = document.getElementById("contact-email-form");
    const contactId = document.getElementById("contact-email-id");
    const contactPrenom = document.getElementById("contact-email-prenom");
    const contactNom = document.getElementById("contact-email-nom");
    const contactAdresse = document.getElementById("contact-email-adresse");
    const contactOrganisation = document.getElementById("contact-email-organisation");
    const contactErreur = document.getElementById("contact-email-erreur");
    const contactSupprimer = document.getElementById("contact-email-supprimer");
    const contactEnregistrer = document.getElementById("contact-email-enregistrer");

    const cases = (root) => Array.from(root.querySelectorAll('input[type="checkbox"]:checked:not(:disabled)'));

    function formatTaille(octets) {
        if (!Number.isFinite(Number(octets))) return "taille inconnue";
        const valeur = Number(octets);
        if (valeur < 1024) return `${valeur} o`;
        if (valeur < 1048576) return `${Math.round(valeur / 1024)} Ko`;
        return `${(valeur / 1048576).toFixed(1).replace(".", ",")} Mo`;
    }

    function compteurs() {
        const nombre = cases(destinatairesRoot).length + cases(contactsRoot).length;
        const documents = cases(documentsRoot);
        const taille = documents.reduce((total, input) => total + Number(input.dataset.taille || 0), 0);
        compteurDest.textContent = `${nombre} destinataire${nombre > 1 ? "s" : ""} sélectionné${nombre > 1 ? "s" : ""}`;
        compteurDocs.textContent = `${documents.length} document${documents.length > 1 ? "s" : ""} — ${formatTaille(taille)}`;
    }

    function idsSemainesSelectionnees() {
        if (!semainesTree) return [];
        return Array.from(semainesTree.querySelectorAll('input[data-periode-id]:checked'))
            .map((input) => Number(input.dataset.periodeId))
            .filter(Number.isFinite);
    }

    function periodesSelectionnees() {
        const ids = new Set(idsSemainesSelectionnees().map(String));
        return [...(donnees.periodes || [])]
            .filter((periode) => ids.has(String(periode.id)))
            .sort((a, b) => String(a.debut).localeCompare(String(b.debut)));
    }

    function mettreAJourLibelleSemaines() {
        if (!semainesLabel) return;
        const selection = periodesSelectionnees();
        if (!selection.length) {
            semainesLabel.textContent = "Choisir des semaines";
        } else if (selection.length === 1) {
            const periode = selection[0];
            semainesLabel.textContent = `${periode.libelle || periode.nom}`;
        } else {
            semainesLabel.textContent = `${selection.length} semaines sélectionnées`;
        }
    }

    function creerGroupeSemaines(titre, classe) {
        const details = document.createElement("details");
        details.className = classe;
        const summary = document.createElement("summary");
        summary.textContent = titre;
        details.appendChild(summary);
        return details;
    }

    function afficherSemaines() {
        if (!semainesTree) return;
        const selectionAvant = new Set(idsSemainesSelectionnees().map(String));
        const periodes = [...(donnees.periodes || [])].sort((a, b) => String(a.debut).localeCompare(String(b.debut)));
        const aujourdHui = new Date();
        const dateLocale = `${aujourdHui.getFullYear()}-${String(aujourdHui.getMonth() + 1).padStart(2, "0")}-${String(aujourdHui.getDate()).padStart(2, "0")}`;
        const estPeriodeActuelle = (periode) => periode.est_actuelle === true
            || String(periode.est_actuelle).toLowerCase() === "true"
            || (String(periode.debut || "") <= dateLocale && dateLocale <= String(periode.fin || ""));
        const periodeActuelle = periodes.find(estPeriodeActuelle);
        semainesTree.innerHTML = "";

        if (!periodes.length) {
            semainesTree.innerHTML = '<p class="empty-note">Aucune semaine enregistrée.</p>';
            mettreAJourLibelleSemaines();
            return;
        }

        const annees = new Map();
        periodes.forEach((periode) => {
            const annee = periode.annee_scolaire || "Année non définie";
            const vacances = periode.vacances || periode.nom || "Autres périodes";
            if (!annees.has(annee)) annees.set(annee, new Map());
            const groupesVacances = annees.get(annee);
            if (!groupesVacances.has(vacances)) groupesVacances.set(vacances, []);
            groupesVacances.get(vacances).push(periode);
        });

        const anneesTriees = [...annees.entries()].sort(([a], [b]) => String(b).localeCompare(String(a), "fr"));
        anneesTriees.forEach(([annee, groupesVacances], indexAnnee) => {
            const groupeAnnee = creerGroupeSemaines(annee, "email-week-year");
            const contientSemaineActuelle = Boolean(
                periodeActuelle && String(periodeActuelle.annee_scolaire || "Année non définie") === String(annee)
            );
            groupeAnnee.open = periodeActuelle ? contientSemaineActuelle : indexAnnee === 0;
            const vacancesTriees = [...groupesVacances.entries()].sort(([, semainesA], [, semainesB]) =>
                String(semainesA[0]?.debut || "").localeCompare(String(semainesB[0]?.debut || ""))
            );
            vacancesTriees.forEach(([vacances, semaines], indexVacances) => {
                const groupeVacances = creerGroupeSemaines(vacances, "email-week-vacation");
                const contientSemaineActuelle = semaines.some(estPeriodeActuelle);
                groupeVacances.open = periodeActuelle
                    ? contientSemaineActuelle
                    : indexAnnee === 0 && indexVacances === 0;
                semaines
                    .sort((a, b) => String(a.debut).localeCompare(String(b.debut)))
                    .forEach((periode) => {
                        const label = document.createElement("label");
                        label.className = "email-week-option";
                        const input = document.createElement("input");
                        input.type = "checkbox";
                        input.dataset.periodeId = String(periode.id);
                        input.checked = selectionAvant.has(String(periode.id));
                        const texte = document.createElement("span");
                        texte.innerHTML = `<strong>${escapeHtml(periode.semaine || periode.nom)}</strong><small>${escapeHtml(formatDateFr(periode.debut))} au ${escapeHtml(formatDateFr(periode.fin))}</small>`;
                        input.addEventListener("change", () => {
                            mettreAJourLibelleSemaines();
                            appliquerFiltresDestinataires();
                        });
                        label.append(input, texte);
                        groupeVacances.appendChild(label);
                    });
                groupeAnnee.appendChild(groupeVacances);
            });
            semainesTree.appendChild(groupeAnnee);
        });
        mettreAJourLibelleSemaines();
    }

    function formatDateFr(iso) {
        const [annee, mois, jour] = String(iso || "").split("-");
        return annee && mois && jour ? `${jour}/${mois}/${annee}` : String(iso || "");
    }

    function afficherConfiguration() {
        const statut = donnees.configuration || {};
        configuration.className = `email-configuration ${!statut.operationnel ? "error" : statut.mode_test ? "test" : "success"}`;
        configuration.textContent = statut.message || "Configuration e-mail inconnue.";
        envoyer.disabled = !statut.operationnel;
    }


    function chevauchePeriode(plage, periode, finExclusive = false) {
        if (!plage || !periode) return false;
        const debut = String(plage.debut || "");
        const fin = String(plage.fin || "");
        if (!debut || !fin) return false;
        return finExclusive
            ? debut <= periode.fin && fin > periode.debut
            : debut <= periode.fin && fin >= periode.debut;
    }

    function remplirFiltreQualifications() {
        if (!filtreQualification) return;
        const valeur = filtreQualification.value;
        const qualifications = [...(donnees.qualifications || [])]
            .sort((a, b) => String(a.nom).localeCompare(String(b.nom), "fr", { sensitivity: "base" }));
        filtreQualification.innerHTML = '<option value="">Toutes</option>';
        qualifications.forEach((qualification) => {
            const option = document.createElement("option");
            option.value = String(qualification.id);
            option.textContent = qualification.nom;
            filtreQualification.appendChild(option);
        });
        if (qualifications.some((qualification) => String(qualification.id) === String(valeur))) {
            filtreQualification.value = String(valeur);
        }
    }

    function remplirFiltreCentres() {
        if (!filtreCentre) return;
        const valeur = filtreCentre.value;
        const centres = new Map();
        (donnees.animateurs || []).forEach((a) => {
            const c = a.centre_prefere;
            if (c?.id) centres.set(String(c.id), c.nom || c.code || `Centre ${c.id}`);
        });
        filtreCentre.innerHTML = '<option value="">Tous</option>';
        [...centres.entries()].sort((a,b) => a[1].localeCompare(b[1], "fr", {sensitivity:"base"})).forEach(([id, nom]) => {
            const option = document.createElement("option"); option.value = id; option.textContent = nom; filtreCentre.appendChild(option);
        });
        if (centres.has(String(valeur))) filtreCentre.value = String(valeur);
    }

    function appliquerFiltresDestinataires() {
        const requete = recherche.value.trim().toLocaleLowerCase("fr");
        const qualification = filtreQualification?.value || "";
        const disponibilite = filtreDisponibilite?.value || "";
        const affectation = filtreAffectation?.value || "";
        const centre = filtreCentre?.value || "";
        const periodes = periodesSelectionnees();
        let visibles = 0;

        destinatairesRoot.querySelectorAll(".email-checkbox-option").forEach((option) => {
            const animateur = (donnees.animateurs || []).find((item) => String(item.id) === option.dataset.animateurId);
            const correspondRecherche = !requete || option.dataset.recherche.includes(requete);
            const correspondQualification = !qualification || (animateur?.qualification_ids || []).map(String).includes(String(qualification));
            const estDisponible = Boolean(periodes.length && periodes.some((periode) =>
                (animateur?.disponibilites || []).some((plage) => chevauchePeriode(plage, periode))
            ));
            const estAffecte = Boolean(periodes.length && periodes.some((periode) =>
                (animateur?.affectations || []).some((plage) => chevauchePeriode(plage, periode, true))
            ));
            const correspondCentre = !centre || String(animateur?.centre_prefere?.id || "") === String(centre);
            const correspondDisponibilite = !disponibilite
                || (disponibilite === "disponible" && estDisponible)
                || (disponibilite === "indisponible" && !estDisponible);
            const correspondAffectation = !affectation
                || (affectation === "affecte" && estAffecte)
                || (affectation === "non-affecte" && !estAffecte);
            option.hidden = !(correspondRecherche && correspondQualification && correspondCentre && correspondDisponibilite && correspondAffectation);
            if (!option.hidden) visibles += 1;
        });

        contactsRoot.querySelectorAll(".email-checkbox-option").forEach((option) => {
            option.hidden = Boolean(requete) && !option.dataset.recherche.includes(requete);
        });

        const filtresSemaineActifs = Boolean(disponibilite || affectation);
        const nombreFiltres = [qualification, disponibilite, affectation, centre].filter(Boolean).length;
        if (filtreCompteur) { filtreCompteur.textContent = String(nombreFiltres); filtreCompteur.hidden = nombreFiltres === 0; }
        if (filtreInfo) {
            filtreInfo.textContent = filtresSemaineActifs && !periodes.length
                ? "Choisis au moins une semaine pour filtrer par dispo ou affectation."
                : `${visibles} salarié${visibles > 1 ? "s" : ""} affiché${visibles > 1 ? "s" : ""}.`;
        }
    }

    function afficherDestinataires() {
        destinatairesRoot.innerHTML = "";
        if (!donnees.animateurs.length) {
            destinatairesRoot.innerHTML = '<p class="empty-note">Aucun salarié enregistré.</p>';
            return;
        }

        donnees.animateurs.forEach((animateur) => {
            const label = document.createElement("label");
            label.className = `email-checkbox-option${animateur.email ? "" : " disabled"}`;
            label.dataset.animateurId = String(animateur.id);
            label.dataset.recherche = [
                animateur.prenom,
                animateur.nom,
                animateur.email,
                ...(animateur.qualifications || []),
                ...(animateur.lieux || []),
            ].join(" ").toLocaleLowerCase("fr");
            label.innerHTML = `
                <input type="checkbox" value="${Number(animateur.id)}" data-type="salarie" ${animateur.email ? "" : "disabled"}>
                <span class="email-option-main">
                    <strong>${escapeHtml(animateur.prenom)} ${escapeHtml(animateur.nom)}</strong>
                    <small>${escapeHtml(animateur.email || "Aucune adresse e-mail")}</small>
                </span>
            `;
            label.querySelector("input").addEventListener("change", compteurs);
            destinatairesRoot.appendChild(label);
        });
        remplirFiltreQualifications();
        remplirFiltreCentres();
        appliquerFiltresDestinataires();
    }

    function afficherContactsExternes() {
        contactsRoot.innerHTML = "";
        const contacts = donnees.contacts_externes || [];
        if (!contacts.length) {
            contactsRoot.innerHTML = '<p class="empty-note">Aucun contact externe enregistré.</p>';
            return;
        }
        contacts.forEach((contact) => {
            const ligne = document.createElement("div");
            ligne.className = "email-contact-row email-checkbox-option";
            ligne.dataset.recherche = [contact.prenom, contact.nom, contact.email, contact.organisation].join(" ").toLocaleLowerCase("fr");
            ligne.innerHTML = `<label><input type="checkbox" value="${Number(contact.id)}" data-type="contact"><span class="email-option-main"><strong>${escapeHtml(`${contact.prenom || ""} ${contact.nom}`.trim())}</strong><small>${escapeHtml(contact.email)}${contact.organisation ? ` · ${escapeHtml(contact.organisation)}` : ""}</small></span></label><button type="button" class="btn btn-ghost btn-small contact-edit">Modifier</button>`;
            ligne.querySelector("input").addEventListener("change", compteurs);
            ligne.querySelector(".contact-edit").addEventListener("click", () => editerContact(contact));
            contactsRoot.appendChild(ligne);
        });
    }

    function fermerContact() {
        contactForm.hidden = true;
        contactId.value = "";
        contactPrenom.value = "";
        contactNom.value = "";
        contactAdresse.value = "";
        contactOrganisation.value = "";
        contactErreur.textContent = "";
        contactSupprimer.hidden = true;
    }
    function editerContact(contact) {
        contactForm.hidden = false; contactId.value = contact.id; contactPrenom.value = contact.prenom || ""; contactNom.value = contact.nom; contactAdresse.value = contact.email; contactOrganisation.value = contact.organisation || ""; contactSupprimer.hidden = false; contactErreur.textContent = ""; contactNom.focus();
    }

    function afficherDocuments() {
        documentsRoot.innerHTML = "";
        if (!donnees.documents.length) {
            documentsRoot.innerHTML = '<p class="empty-note">Aucun document disponible. L’envoi reste possible sans pièce jointe.</p>';
            return;
        }

        donnees.documents.forEach((documentItem) => {
            const label = document.createElement("label");
            label.className = "email-checkbox-option";
            label.innerHTML = `
                <input type="checkbox" value="${Number(documentItem.id)}" data-taille="${Number(documentItem.taille || 0)}">
                <span class="email-option-main">
                    <strong>${escapeHtml(documentItem.titre)}</strong>
                    <small>${escapeHtml(documentItem.libelle_periode)} · ${escapeHtml(formatTaille(documentItem.taille))}</small>
                </span>
            `;
            label.querySelector("input").addEventListener("change", compteurs);
            documentsRoot.appendChild(label);
        });
    }

    function afficherModelesEnvoi() {
        if (!modeleSelect) return;
        const selection = modeleSelect.value;
        modeleSelect.innerHTML = '<option value="">Message personnalisé</option>';
        (donnees.modeles || []).forEach((modele) => {
            const option = document.createElement("option");
            option.value = String(modele.id);
            option.textContent = modele.nom;
            modeleSelect.appendChild(option);
        });
        if ([...modeleSelect.options].some((option) => option.value === selection)) {
            modeleSelect.value = selection;
        }
    }

    function insererVariable(champ, code) {
        if (!champ) return;
        const debut = Number.isInteger(champ.selectionStart) ? champ.selectionStart : champ.value.length;
        const fin = Number.isInteger(champ.selectionEnd) ? champ.selectionEnd : debut;
        champ.value = `${champ.value.slice(0, debut)}${code}${champ.value.slice(fin)}`;
        const position = debut + code.length;
        champ.focus();
        champ.setSelectionRange?.(position, position);
    }

    function afficherVariables(root, obtenirChamp) {
        if (!root) return;
        root.innerHTML = "";
        (donnees.variables || []).forEach((variable) => {
            const bouton = document.createElement("button");
            bouton.type = "button";
            bouton.className = "email-variable-chip";
            bouton.textContent = variable.code;
            bouton.title = variable.libelle;
            bouton.addEventListener("click", () => insererVariable(obtenirChamp(), variable.code));
            root.appendChild(bouton);
        });
    }

    function afficherHistorique() {
        historiqueRoot.innerHTML = "";
        const historique = donnees.historique || [];
        if (!historique.length) {
            historiqueRoot.innerHTML = '<p class="empty-note">Aucun e-mail envoyé pour l’instant.</p>';
            return;
        }

        historique.forEach((envoi) => {
            const article = document.createElement("article");
            article.className = "email-history-card";
            const date = new Date(envoi.date_creation).toLocaleString("fr-FR", { dateStyle: "medium", timeStyle: "short" });
            article.innerHTML = `
                <div class="history-card-main">
                    <div><h3>${escapeHtml(envoi.objet)}</h3><p>${escapeHtml(date)}${envoi.mode_test ? " · Mode test" : ""}</p></div>
                    <span class="history-status ${envoi.nombre_echecs ? "warning" : "success"}">
                        ${envoi.nombre_envoyes} envoyé${envoi.nombre_envoyes > 1 ? "s" : ""}${envoi.nombre_echecs ? ` · ${envoi.nombre_echecs} échec${envoi.nombre_echecs > 1 ? "s" : ""}` : ""}
                    </span>
                </div>
                <p class="history-documents"><strong>Documents :</strong> ${envoi.documents.length ? envoi.documents.map(escapeHtml).join(", ") : "Aucun"}</p>
                <div class="history-errors"></div>
            `;
            if (envoi.echecs?.length) {
                const details = document.createElement("details");
                details.innerHTML = `<summary>Voir les échecs</summary><ul>${envoi.echecs.map((item) => `
                    <li><strong>${escapeHtml(item.prenom)} ${escapeHtml(item.nom)}</strong> (${escapeHtml(item.email)}) : ${escapeHtml(item.erreur || "Erreur inconnue")}</li>
                `).join("")}</ul>`;
                article.querySelector(".history-errors").appendChild(details);
            }
            historiqueRoot.appendChild(article);
        });
    }

    function reinitialiserModele() {
        modeleForm.reset();
        modeleIdInput.value = "";
        modeleActifInput.checked = true;
        modeleTitre.textContent = "Nouveau modèle";
        modeleErreur.textContent = "";
        modeleSupprimer.hidden = true;
        modelesListe.querySelectorAll(".email-template-list-item").forEach((item) => item.classList.remove("active"));
        champVariableModeleActif = modeleMessageInput;
    }

    function editerModele(modeleId) {
        const modele = modelesGestion.find((item) => Number(item.id) === Number(modeleId));
        if (!modele) {
            reinitialiserModele();
            return;
        }
        modeleIdInput.value = String(modele.id);
        modeleNomInput.value = modele.nom;
        modeleObjetInput.value = modele.objet;
        modeleMessageInput.value = modele.message;
        modeleActifInput.checked = Boolean(modele.actif);
        modeleTitre.textContent = "Modifier le modèle";
        modeleErreur.textContent = "";
        modeleSupprimer.hidden = false;
        modelesListe.querySelectorAll(".email-template-list-item").forEach((item) => {
            item.classList.toggle("active", Number(item.dataset.modeleId) === Number(modele.id));
        });
    }

    function afficherGestionModeles() {
        modelesCompteur.textContent = `${modelesGestion.length} modèle${modelesGestion.length > 1 ? "s" : ""}`;
        modelesListe.innerHTML = "";
        if (!modelesGestion.length) {
            modelesListe.innerHTML = '<div class="email-template-empty"><strong>Aucun modèle</strong><p>Crée ton premier modèle avec le formulaire.</p></div>';
            reinitialiserModele();
            return;
        }

        modelesGestion.forEach((modele) => {
            const bouton = document.createElement("button");
            bouton.type = "button";
            bouton.className = "email-template-list-item";
            bouton.dataset.modeleId = String(modele.id);
            bouton.innerHTML = `
                <span><strong>${escapeHtml(modele.nom)}</strong><small>${escapeHtml(modele.objet)}</small></span>
                <span class="email-template-status ${modele.actif ? "active" : "inactive"}">${modele.actif ? "Actif" : "Inactif"}</span>
            `;
            bouton.addEventListener("click", () => editerModele(modele.id));
            modelesListe.appendChild(bouton);
        });
    }

    async function chargerModeles() {
        const payload = await apiFetch("/api/modeles-email/");
        modelesGestion = payload.modeles || [];
        if (payload.variables?.length) donnees.variables = payload.variables;
        donnees.modeles = modelesGestion.filter((modele) => modele.actif);
        afficherModelesEnvoi();
        afficherGestionModeles();
        afficherVariables(variablesRoot, () => champVariableActif || messageInput);
        afficherVariables(modeleVariablesRoot, () => champVariableModeleActif || modeleMessageInput);
    }

    async function chargerEnvois() {
        donnees = await apiFetch("/api/envois-email/");
        afficherConfiguration();
        afficherSemaines();
        afficherDestinataires();
        afficherContactsExternes();
        afficherDocuments();
        afficherModelesEnvoi();
        afficherVariables(variablesRoot, () => champVariableActif || messageInput);
        afficherHistorique();
        compteurs();
        recherche.dispatchEvent(new Event("input"));
    }

    async function charger() {
        // Les destinataires constituent le cœur de l’écran : leur chargement est
        // volontairement indépendant des modèles. Un problème sur les modèles
        // ne doit plus vider ou bloquer la liste des salariés.
        try {
            await chargerEnvois();
        } catch (err) {
            configuration.className = "email-configuration error";
            configuration.textContent = erreurMessage(err, "Impossible de charger la liste des salariés.");
            destinatairesRoot.innerHTML = '<p class="empty-note error-note">Impossible de charger les destinataires.</p>';
            envoyer.disabled = true;
            return;
        }

        try {
            await chargerModeles();
        } catch (err) {
            modelesGestion = [];
            donnees.modeles = [];
            afficherModelesEnvoi();
            afficherGestionModeles();
            if (modeleErreur) {
                modeleErreur.textContent = erreurMessage(err, "Les modèles d’e-mails ne sont pas disponibles pour le moment.");
            }
        }
    }

    function cocher(root, valeur, visiblesSeulement = false) {
        root.querySelectorAll('input[type="checkbox"]:not(:disabled)').forEach((input) => {
            const option = input.closest(".email-checkbox-option");
            if (!visiblesSeulement || !option.hidden) input.checked = valeur;
        });
        compteurs();
    }

    recherche.addEventListener("input", appliquerFiltresDestinataires);
    [filtreQualification, filtreDisponibilite, filtreAffectation].forEach((filtre) => filtre?.addEventListener("change", appliquerFiltresDestinataires));
    semainesToggle?.addEventListener("click", () => {
        const ouvert = semainesMenu?.hidden !== false;
        if (semainesMenu) semainesMenu.hidden = !ouvert;
        semainesToggle.setAttribute("aria-expanded", String(ouvert));
    });
    semainesEffacer?.addEventListener("click", () => {
        semainesTree?.querySelectorAll('input[data-periode-id]').forEach((input) => { input.checked = false; });
        mettreAJourLibelleSemaines();
        appliquerFiltresDestinataires();
    });
    document.addEventListener("click", (event) => {
        if (semainesPicker && semainesMenu && !semainesPicker.contains(event.target)) {
            semainesMenu.hidden = true;
            semainesToggle?.setAttribute("aria-expanded", "false");
        }
    });
    document.addEventListener("keydown", (event) => {
        if (event.key === "Escape" && semainesMenu && !semainesMenu.hidden) {
            semainesMenu.hidden = true;
            semainesToggle?.setAttribute("aria-expanded", "false");
            semainesToggle?.focus();
        }
    });

    document.getElementById("destinataires-tous").addEventListener("click", () => { cocher(destinatairesRoot, true, true); cocher(contactsRoot, true, true); });
    document.getElementById("destinataires-aucun").addEventListener("click", () => { cocher(destinatairesRoot, false); cocher(contactsRoot, false); });
    document.getElementById("documents-tous").addEventListener("click", () => cocher(documentsRoot, true));
    document.getElementById("documents-aucun").addEventListener("click", () => cocher(documentsRoot, false));

    [objetInput, messageInput].forEach((champ) => champ?.addEventListener("focus", () => { champVariableActif = champ; }));
    [modeleObjetInput, modeleMessageInput].forEach((champ) => champ?.addEventListener("focus", () => { champVariableModeleActif = champ; }));

    modeleSelect?.addEventListener("change", () => {
        const modele = (donnees.modeles || []).find((item) => Number(item.id) === Number(modeleSelect.value));
        if (!modele) return;
        objetInput.value = modele.objet;
        messageInput.value = modele.message;
        messageInput.focus();
    });

    document.getElementById("modele-email-nouveau").addEventListener("click", () => {
        reinitialiserModele();
        modeleNomInput.focus();
    });
    document.getElementById("modele-email-annuler").addEventListener("click", reinitialiserModele);

    modeleForm.addEventListener("submit", async (event) => {
        event.preventDefault();
        modeleErreur.textContent = "";
        const id = modeleIdInput.value;
        const payload = {
            nom: modeleNomInput.value.trim(),
            objet: modeleObjetInput.value.trim(),
            message: modeleMessageInput.value.trim(),
            actif: modeleActifInput.checked,
        };
        if (!payload.nom || !payload.objet || !payload.message) {
            modeleErreur.textContent = "Le nom, l’objet et le message sont obligatoires.";
            return;
        }

        const bouton = document.getElementById("modele-email-enregistrer");
        const texteInitial = bouton.textContent;
        bouton.disabled = true;
        bouton.textContent = "Enregistrement…";
        try {
            const modele = await apiFetch(id ? `/api/modeles-email/${id}/` : "/api/modeles-email/", {
                method: id ? "PATCH" : "POST",
                body: JSON.stringify(payload),
            });
            await chargerModeles();
            editerModele(modele.id);
            afficherToast(id ? "Modèle modifié." : "Modèle créé.");
        } catch (err) {
            modeleErreur.textContent = erreurMessage(err, "Impossible d’enregistrer le modèle.");
        } finally {
            bouton.disabled = false;
            bouton.textContent = texteInitial;
        }
    });

    modeleSupprimer.addEventListener("click", async () => {
        const id = modeleIdInput.value;
        const modele = modelesGestion.find((item) => Number(item.id) === Number(id));
        if (!modele || !confirm(`Supprimer définitivement le modèle « ${modele.nom} » ?`)) return;
        modeleErreur.textContent = "";
        try {
            await apiFetch(`/api/modeles-email/${id}/`, { method: "DELETE" });
            await chargerModeles();
            reinitialiserModele();
            afficherToast("Modèle supprimé.");
        } catch (err) {
            modeleErreur.textContent = erreurMessage(err, "Impossible de supprimer le modèle.");
        }
    });

    document.getElementById("contact-email-nouveau").addEventListener("click", () => { fermerContact(); contactForm.hidden = false; contactNom.focus(); });
    document.getElementById("contact-email-annuler").addEventListener("click", fermerContact);
    contactEnregistrer.addEventListener("click", async () => {
        contactErreur.textContent = "";
        if (!contactNom.value.trim() || !contactAdresse.value.trim()) {
            contactErreur.textContent = "Le nom et l’adresse e-mail sont obligatoires.";
            return;
        }
        if (!contactAdresse.checkValidity()) {
            contactErreur.textContent = "L’adresse e-mail n’est pas valide.";
            contactAdresse.focus();
            return;
        }
        const id = contactId.value;
        try {
            await apiFetch(id ? `/api/contacts-email/${id}/` : "/api/contacts-email/", {method: id ? "PATCH" : "POST", body: JSON.stringify({prenom: contactPrenom.value.trim(), nom: contactNom.value.trim(), email: contactAdresse.value.trim(), organisation: contactOrganisation.value.trim(), actif: true})});
            fermerContact(); await chargerEnvois(); afficherToast(id ? "Contact modifié." : "Contact ajouté.");
        } catch (err) { contactErreur.textContent = erreurMessage(err, "Impossible d’enregistrer le contact."); }
    });
    contactSupprimer.addEventListener("click", async () => {
        if (!contactId.value || !confirm("Supprimer définitivement ce contact externe ?")) return;
        try { await apiFetch(`/api/contacts-email/${contactId.value}/`, {method: "DELETE"}); fermerContact(); await chargerEnvois(); afficherToast("Contact supprimé."); }
        catch (err) { contactErreur.textContent = erreurMessage(err, "Impossible de supprimer le contact."); }
    });

    form.addEventListener("submit", async (event) => {
        event.preventDefault();
        erreur.textContent = "";
        resultat.hidden = true;

        const animateurIds = cases(destinatairesRoot).map((input) => Number(input.value));
        const contactIds = cases(contactsRoot).map((input) => Number(input.value));
        const documentIds = cases(documentsRoot).map((input) => Number(input.value));
        const objet = objetInput.value.trim();
        const message = messageInput.value.trim();

        if (!animateurIds.length && !contactIds.length) {
            erreur.textContent = "Choisis au moins un destinataire.";
            return;
        }
        if (!objet || !message) {
            erreur.textContent = "L’objet et le message sont obligatoires.";
            return;
        }
        const nombreDestinataires = animateurIds.length + contactIds.length;
        if (!confirm(`Envoyer ce message séparément à ${nombreDestinataires} destinataire${nombreDestinataires > 1 ? "s" : ""} ?`)) return;

        const texteInitial = envoyer.textContent;
        envoyer.disabled = true;
        envoyer.textContent = "Envoi en cours…";
        try {
            const reponse = await apiFetch("/api/envois-email/", {
                method: "POST",
                body: JSON.stringify({
                    animateur_ids: animateurIds,
                    contact_ids: contactIds,
                    document_ids: documentIds,
                    periode_ids: idsSemainesSelectionnees(),
                    objet,
                    message,
                }),
            });
            resultat.hidden = false;
            resultat.className = `email-resultat ${reponse.nombre_echecs ? "warning" : "success"}`;
            resultat.textContent = `${reponse.nombre_envoyes} e-mail${reponse.nombre_envoyes > 1 ? "s" : ""} envoyé${reponse.nombre_envoyes > 1 ? "s" : ""}${reponse.mode_test ? " en mode test" : ""}${reponse.nombre_echecs ? `, ${reponse.nombre_echecs} en échec` : ""}.`;
            if (!reponse.nombre_echecs) {
                form.reset();
                semainesTree?.querySelectorAll('input[data-periode-id]').forEach((input) => { input.checked = false; });
                mettreAJourLibelleSemaines();
                recherche.value = "";
            }
            afficherToast(reponse.nombre_echecs ? "Envoi terminé avec des échecs." : "E-mails envoyés.", Boolean(reponse.nombre_echecs));
            await chargerEnvois();
        } catch (err) {
            erreur.textContent = erreurMessage(err, "L’envoi a échoué.");
        } finally {
            envoyer.textContent = texteInitial;
            envoyer.disabled = !(donnees.configuration || {}).operationnel;
        }
    });

    reinitialiserModele();
    charger();

    [filtreCentre].forEach((select) => select?.addEventListener("change", appliquerFiltresDestinataires));
    filtreReset?.addEventListener("click", () => {
        [filtreQualification, filtreDisponibilite, filtreAffectation, filtreCentre].forEach((select) => { if (select) select.value = ""; });
        appliquerFiltresDestinataires();
    });
    if (filtreDetails) {
        document.addEventListener("click", (event) => {
            if (filtreDetails.open && !filtreDetails.contains(event.target)) filtreDetails.removeAttribute("open");
        });
    }
});
