(function(){
  function esc(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));}
  function fr(d){if(!d)return "";return new Date(`${d}T12:00:00`).toLocaleDateString("fr-FR");}
  function init(root){
    const toggle=root.querySelector('.week-picker__toggle'),menu=root.querySelector('.week-picker__menu'),tree=root.querySelector('.week-picker__tree');
    if(!toggle||!menu||!tree)return;
    toggle.addEventListener('click',()=>{const open=menu.hidden;menu.hidden=!open;toggle.setAttribute('aria-expanded',String(open));});
    document.addEventListener('click',e=>{if(!root.contains(e.target)){menu.hidden=true;toggle.setAttribute('aria-expanded','false');}});
    fetch('/api/periodes-scolaires/',{headers:{Accept:'application/json'}}).then(r=>{if(!r.ok)throw new Error();return r.json();}).then(items=>{
      const groups=new Map();items.forEach(p=>{const y=p.annee_scolaire||'Année non définie',v=p.vacances||p.nom||'Autres périodes';if(!groups.has(y))groups.set(y,new Map());if(!groups.get(y).has(v))groups.get(y).set(v,[]);groups.get(y).get(v).push(p);});
      tree.innerHTML=[...groups.entries()].sort(([a],[b])=>String(b).localeCompare(String(a),'fr')).map(([y,vs],yi)=>`<details class="week-picker__year" ${yi===0?'open':''}><summary>${esc(y)}</summary>${[...vs.entries()].sort(([,a],[,b])=>String(a[0]?.debut||'').localeCompare(String(b[0]?.debut||''))).map(([v,weeks],vi)=>`<details class="week-picker__vacation" ${yi===0&&vi===0?'open':''}><summary>${esc(v)}</summary>${weeks.sort((a,b)=>a.debut.localeCompare(b.debut)).map(p=>`<button class="week-picker__option" type="button" data-week-date="${esc(p.debut)}"><span><strong>${esc(p.semaine||p.nom)}</strong><small>${esc(fr(p.debut))} au ${esc(fr(p.fin))}</small></span></button>`).join('')}</details>`).join('')}</details>`).join('')||'<p class="empty-note">Aucune semaine enregistrée.</p>';
      tree.querySelectorAll('[data-week-date]').forEach(btn=>btn.addEventListener('click',()=>{root.dispatchEvent(new CustomEvent('week-picker:select',{bubbles:true,detail:{date:btn.dataset.weekDate}}));menu.hidden=true;toggle.setAttribute('aria-expanded','false');}));
    }).catch(()=>{tree.innerHTML='<p class="empty-note">Les semaines n’ont pas pu être chargées.</p>';});
  }
  document.addEventListener('DOMContentLoaded',()=>document.querySelectorAll('.week-picker').forEach(init));
})();
